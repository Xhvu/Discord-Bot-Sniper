
import discord
from discord.ext import commands, tasks
import random
import string
import asyncio
import re
import aiohttp
import json
import time

class BoostGenerator:
    def __init__(self):
        self.services = {
            'nitro_1month': {'length': 16, 'prefix': 'N1'},
            'nitro_3month': {'length': 20, 'prefix': 'N3'},
            'nitro_classic': {'length': 18, 'prefix': 'NC'},
            'game_pass': {'length': 24, 'prefix': 'GP'},
            'epic_games': {'length': 16, 'prefix': 'EG'},
            'twitch_prime': {'length': 22, 'prefix': 'TP'},
            'xbox_promo': {'length': 20, 'prefix': 'XB'},
            'steam_promo': {'length': 18, 'prefix': 'ST'},
            'boost_trial': {'length': 16, 'prefix': 'BT'},
            'server_boost': {'length': 20, 'prefix': 'SB'},
            'steam_account': {'length': 24, 'prefix': 'SA'},
            'spotify_premium': {'length': 20, 'prefix': 'SP'},
            'netflix_trial': {'length': 18, 'prefix': 'NF'},
            'youtube_premium': {'length': 22, 'prefix': 'YT'}
        }
    
    def generate_code(self, service_type):
        if service_type not in self.services:
            return None
        
        service = self.services[service_type]
        prefix = service['prefix']
        length = service['length']
        
        remaining_length = length - len(prefix)
        random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=remaining_length))
        
        return f"{prefix}{random_part}"
    
    def generate_nitro_gift_token(self):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=16))
    
    def get_random_service(self):
        return random.choice(list(self.services.keys()))

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True
bot = commands.Bot(command_prefix='!', intents=intents)
generator = BoostGenerator()

# Sniping configuration
SNIPE_ENABLED = True  # Auto-enable sniping on startup
EXCLUDED_SERVERS = set()  # Servers to exclude from monitoring
USER_ID = None  # Your Discord user ID for notifications
LAST_CLAIM_TIME = {}  # Rate limiting for claims
AUTO_CLAIM_ALL = True  # Automatically claim everything found

# Expanded regex patterns for detecting all types of codes
NITRO_PATTERNS = [
    r'discord\.gift/([a-zA-Z0-9]{16,})',
    r'discord\.com/gifts/([a-zA-Z0-9]{16,})',
    r'discordapp\.com/gifts/([a-zA-Z0-9]{16,})',
    r'nitro\.gift/([a-zA-Z0-9]{16,})',
    r'discord\.app/gifts/([a-zA-Z0-9]{16,})',
]

NETFLIX_PATTERNS = [
    r'netflix\.com/redeem/([a-zA-Z0-9]{8,16})',
    r'netflix\.com/gift/([a-zA-Z0-9]{8,16})',
    r'netflix\.gift/([a-zA-Z0-9]{8,16})',
    r'NETFLIX[A-Z0-9]{8,12}',
    r'NF[A-Z0-9]{8,16}',
]

SPOTIFY_PATTERNS = [
    r'spotify\.com/redeem/([a-zA-Z0-9]{8,16})',
    r'spotify\.gift/([a-zA-Z0-9]{8,16})',
    r'SPOTIFY[A-Z0-9]{8,12}',
    r'SP[A-Z0-9]{8,16}',
]

AMAZON_PATTERNS = [
    r'amazon\.com/redeem/([a-zA-Z0-9-]{10,20})',
    r'amazon\.gift/([a-zA-Z0-9-]{10,20})',
    r'AMAZON[A-Z0-9]{8,16}',
    r'[A-Z0-9]{4}-[A-Z0-9]{6}-[A-Z0-9]{4}',  # Amazon format
]

EPIC_GAMES_PATTERNS = [
    r'epicgames\.com/redeem/([a-zA-Z0-9]{16,})',
    r'epicgames\.store/redeem/([a-zA-Z0-9]{16,})',
    r'EPIC[A-Z0-9]{12,16}',
    r'EG[A-Z0-9]{16,20}',
]

XBOX_PATTERNS = [
    r'xbox\.com/redeem/([a-zA-Z0-9-]{20,25})',
    r'microsoft\.com/redeem/([a-zA-Z0-9-]{20,25})',
    r'XBOX[A-Z0-9]{16,20}',
    r'[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}',  # Xbox format
]

PLAYSTATION_PATTERNS = [
    r'playstation\.com/redeem/([a-zA-Z0-9]{12,16})',
    r'PSN[A-Z0-9]{12,16}',
    r'PS[A-Z0-9]{12,16}',
]

TWITCH_PATTERNS = [
    r'twitch\.tv/prime/([a-zA-Z0-9]{16,})',
    r'twitch\.amazon\.com/prime/([a-zA-Z0-9]{16,})',
    r'TWITCH[A-Z0-9]{12,16}',
    r'TP[A-Z0-9]{16,20}',
]

GOOGLE_PLAY_PATTERNS = [
    r'play\.google\.com/redeem/([a-zA-Z0-9]{16,})',
    r'googleplay\.com/redeem/([a-zA-Z0-9]{16,})',
    r'GPLAY[A-Z0-9]{12,16}',
    r'GP[A-Z0-9]{16,20}',
]

APPLE_PATTERNS = [
    r'apple\.com/redeem/([a-zA-Z0-9]{16,})',
    r'itunes\.apple\.com/redeem/([a-zA-Z0-9]{16,})',
    r'APPLE[A-Z0-9]{12,16}',
    r'ITUNES[A-Z0-9]{12,16}',
]

PROMO_PATTERNS = [
    r'[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}',  # XXX-XXXX-XXXX format
    r'[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}',  # XXXXX-XXXXX-XXXXX format
    r'[A-Z0-9]{3}-[A-Z0-9]{4}-[A-Z0-9]{3}',  # XXX-XXXX-XXX format
    r'[A-Z0-9]{16,25}',  # Long alphanumeric codes
    r'[A-Z]{2}[0-9]{2}[A-Z0-9]{8,16}',  # Pattern like AB12XXXXXXXX
    r'PROMO[A-Z0-9]{8,16}',
    r'GIFT[A-Z0-9]{8,16}',
    r'CODE[A-Z0-9]{8,16}',
]

ACCOUNT_PATTERNS = [
    r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}):([^\s]{6,})',  # email:password
    r'Username:\s*([^\s]+)\s*Password:\s*([^\s]+)',  # Username: X Password: Y
    r'Login:\s*([^\s]+)\s*Pass:\s*([^\s]+)',  # Login: X Pass: Y
    r'User:\s*([^\s]+)\s*Pwd:\s*([^\s]+)',  # User: X Pwd: Y
    r'Email:\s*([^\s]+)\s*Pass:\s*([^\s]+)',  # Email: X Pass: Y
]

STEAM_KEY_PATTERNS = [
    r'[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}',  # Steam key format
    r'Steam Key:\s*([A-Z0-9-]{17,})',
    r'Key:\s*([A-Z0-9-]{17,})',
]

CRYPTO_PATTERNS = [
    r'[13][a-km-zA-HJ-NP-Z1-9]{25,34}',  # Bitcoin addresses
    r'0x[a-fA-F0-9]{40}',  # Ethereum addresses
    r'[A-Za-z0-9]{44}',  # Potential wallet seeds (partial)
]

async def claim_nitro_gift(code):
    """Attempt to claim a Nitro gift code"""
    try:
        # Ultra-fast rate limiting for aggressive claiming
        current_time = time.time()
        if 'nitro' in LAST_CLAIM_TIME and current_time - LAST_CLAIM_TIME['nitro'] < 0.5:
            return False, "Rate limited"
        
        LAST_CLAIM_TIME['nitro'] = current_time
        
        async with aiohttp.ClientSession() as session:
            url = f"https://discord.com/api/v9/entitlements/gift-codes/{code}/redeem"
            headers = {
                'Authorization': f'Bot {bot.http.token}',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            async with session.post(url, headers=headers) as response:
                if response.status == 200:
                    return True, "Successfully claimed!"
                elif response.status == 404:
                    return False, "Code not found or already claimed"
                elif response.status == 400:
                    return False, "Invalid code format"
                elif response.status == 429:
                    return False, "Rate limited by Discord"
                else:
                    return False, f"Error {response.status}"
    except Exception as e:
        return False, f"Network error: {str(e)}"

async def notify_user(channel, message, success=False, code_type="Unknown"):
    """Send notification to user"""
    if USER_ID:
        try:
            user = bot.get_user(USER_ID)
            if user:
                color = 0x00ff00 if success else 0xff0000
                embed = discord.Embed(
                    title=f"🎯 {code_type} Sniper Alert",
                    description=message,
                    color=color,
                    timestamp=discord.utils.utcnow()
                )
                embed.add_field(name="Channel", value=f"#{channel.name}", inline=True)
                embed.add_field(name="Server", value=channel.guild.name, inline=True)
                embed.add_field(name="Type", value=code_type, inline=True)
                await user.send(embed=embed)
        except Exception as e:
            print(f"Failed to notify user: {e}")

@bot.event
async def on_ready():
    global USER_ID
    print(f'{bot.user} has connected to Discord!')
    print(f'Bot is monitoring {len(bot.guilds)} servers')
    
    # Try to get your user ID from the bot owner
    app_info = await bot.application_info()
    USER_ID = app_info.owner.id
    
    # Auto-enable aggressive sniping
    global SNIPE_ENABLED
    SNIPE_ENABLED = True
    
    # Start the monitoring task
    if not monitor_all_servers.is_running():
        monitor_all_servers.start()
    
    print(f'🎯 ULTRA-AGGRESSIVE SNIPER ACTIVE! Auto-claiming ALL codes across {len(bot.guilds)} servers!')
    print(f'📡 Monitoring: Nitro, Netflix, Spotify, Amazon, Gaming, Twitch, Apple, Google Play, Promos, Accounts, Crypto')
    print(f'⚡ Rate limit: 0.5 seconds between claims')
    print(f'🤖 Auto-join: Use !mass_invite or !join to add bot to more servers')
    print(f'🔥 ULTRA MODE: Detecting 10+ different code types with enhanced patterns!')

@tasks.loop(seconds=1)
async def monitor_all_servers():
    """Background task to monitor all servers for new messages"""
    pass  # This is handled by on_message event

@bot.event
async def on_message(message):
    # Don't respond to bot messages or own messages
    if message.author.bot or message.author == bot.user:
        return
    
    # Only monitor if sniping is enabled and server is not excluded
    if SNIPE_ENABLED and message.guild and message.guild.id not in EXCLUDED_SERVERS:
        content = message.content
        
        # Check for Nitro gift links
        for pattern in NITRO_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Nitro code in #{message.channel.name}: {code}")
                success, result = await claim_nitro_gift(code)
                
                if success:
                    await notify_user(message.channel, f"✅ Successfully claimed Nitro gift: `{code}`", True, "Nitro Gift")
                    print(f"✅ Successfully claimed: {code}")
                else:
                    await notify_user(message.channel, f"❌ Failed to claim `{code}`: {result}", False, "Nitro Gift")
                    print(f"❌ Failed to claim {code}: {result}")
        
        # Check for Netflix codes
        for pattern in NETFLIX_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Netflix code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎬 Auto-sniped Netflix code: `{code}`", True, "Netflix Gift")
        
        # Check for Spotify codes
        for pattern in SPOTIFY_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Spotify code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎵 Auto-sniped Spotify code: `{code}`", True, "Spotify Gift")
        
        # Check for Amazon codes
        for pattern in AMAZON_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Amazon code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"📦 Auto-sniped Amazon code: `{code}`", True, "Amazon Gift")
        
        # Check for Epic Games codes
        for pattern in EPIC_GAMES_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Epic Games code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎮 Auto-sniped Epic Games code: `{code}`", True, "Epic Games")
        
        # Check for Xbox codes
        for pattern in XBOX_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Xbox code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎮 Auto-sniped Xbox code: `{code}`", True, "Xbox Gift")
        
        # Check for PlayStation codes
        for pattern in PLAYSTATION_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found PlayStation code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎮 Auto-sniped PlayStation code: `{code}`", True, "PlayStation Gift")
        
        # Check for Twitch codes
        for pattern in TWITCH_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Twitch code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🟣 Auto-sniped Twitch code: `{code}`", True, "Twitch Prime")
        
        # Check for Google Play codes
        for pattern in GOOGLE_PLAY_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Google Play code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"📱 Auto-sniped Google Play code: `{code}`", True, "Google Play Gift")
        
        # Check for Apple/iTunes codes
        for pattern in APPLE_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for code in matches:
                print(f"🎯 Found Apple code in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🍎 Auto-sniped Apple/iTunes code: `{code}`", True, "Apple Gift")
        
        # Check for promotional codes
        for pattern in PROMO_PATTERNS:
            matches = re.findall(pattern, content)
            for code in matches:
                if len(code) >= 6:  # Even lower threshold for more detection
                    print(f"🎯 Found promo code in #{message.channel.name}: {code}")
                    await notify_user(message.channel, f"🎟️ Auto-sniped promo code: `{code}`", True, "Promo Code")
        
        # Check for Steam keys
        for pattern in STEAM_KEY_PATTERNS:
            matches = re.findall(pattern, content)
            for code in matches:
                print(f"🎯 Found Steam key in #{message.channel.name}: {code}")
                await notify_user(message.channel, f"🎮 Auto-sniped Steam key: `{code}`", True, "Steam Key")
        
        # Check for account credentials
        for pattern in ACCOUNT_PATTERNS:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple) and len(match) == 2:
                    username, password = match
                    print(f"🎯 Found account credentials in #{message.channel.name}: {username}")
                    await notify_user(message.channel, f"🔐 Auto-sniped account: `{username}:{password}`", True, "Account Login")
        
        # Check for crypto addresses/keys
        for pattern in CRYPTO_PATTERNS:
            matches = re.findall(pattern, content)
            for address in matches:
                print(f"🎯 Found crypto address in #{message.channel.name}: {address}")
                await notify_user(message.channel, f"💰 Auto-sniped crypto: `{address}`", True, "Crypto Address")
    
    # Process commands
    await bot.process_commands(message)

@bot.command(name='snipe_enable')
async def enable_sniping(ctx):
    """Enable automatic code sniping across all servers"""
    global SNIPE_ENABLED
    SNIPE_ENABLED = True
    
    embed = discord.Embed(
        title="🎯 Global Sniper Activated",
        description="Automatic code sniping is now **ENABLED** across all servers",
        color=0x00ff00
    )
    embed.add_field(name="Monitoring", value=f"{len(bot.guilds)} servers", inline=True)
    embed.add_field(name="Excluded", value=f"{len(EXCLUDED_SERVERS)} servers", inline=True)
    embed.add_field(name="Types", value="Nitro, Promo, Steam, Accounts, Crypto", inline=False)
    embed.add_field(name="⚠️ Warning", value="This may violate Discord ToS", inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_disable')
async def disable_sniping(ctx):
    """Disable automatic code sniping"""
    global SNIPE_ENABLED
    SNIPE_ENABLED = False
    
    embed = discord.Embed(
        title="🛑 Global Sniper Deactivated",
        description="Automatic code sniping is now **DISABLED**",
        color=0xff0000
    )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_exclude_server')
async def exclude_server(ctx, server_id: int = None):
    """Exclude a server from monitoring"""
    if not server_id:
        server_id = ctx.guild.id
    
    EXCLUDED_SERVERS.add(server_id)
    
    server = bot.get_guild(server_id)
    server_name = server.name if server else f"Server ID: {server_id}"
    
    embed = discord.Embed(
        title="❌ Server Excluded",
        description=f"No longer monitoring: **{server_name}**",
        color=0xff9500
    )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_include_server')
async def include_server(ctx, server_id: int = None):
    """Include a server back in monitoring"""
    if not server_id:
        server_id = ctx.guild.id
    
    EXCLUDED_SERVERS.discard(server_id)
    
    server = bot.get_guild(server_id)
    server_name = server.name if server else f"Server ID: {server_id}"
    
    embed = discord.Embed(
        title="✅ Server Included",
        description=f"Now monitoring: **{server_name}**",
        color=0x00bfff
    )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_status')
async def snipe_status(ctx):
    """Show current sniping status across all servers"""
    
    status = "🟢 ACTIVE" if SNIPE_ENABLED else "🔴 INACTIVE"
    monitored_servers = len(bot.guilds) - len(EXCLUDED_SERVERS)
    
    embed = discord.Embed(
        title="🎯 Global Sniper Status",
        color=0x00ff00 if SNIPE_ENABLED else 0xff0000
    )
    
    embed.add_field(name="Status", value=status, inline=True)
    embed.add_field(name="Total Servers", value=f"{len(bot.guilds)}", inline=True)
    embed.add_field(name="Monitoring", value=f"{monitored_servers}", inline=True)
    embed.add_field(name="Excluded", value=f"{len(EXCLUDED_SERVERS)}", inline=True)
    embed.add_field(name="User ID", value=f"`{USER_ID}`" if USER_ID else "Not set", inline=True)
    embed.add_field(name="Types", value="Nitro, Promo, Steam, Accounts, Crypto", inline=True)
    
    if EXCLUDED_SERVERS:
        excluded_names = []
        for server_id in list(EXCLUDED_SERVERS)[:5]:  # Show first 5
            server = bot.get_guild(server_id)
            if server:
                excluded_names.append(server.name)
        
        if excluded_names:
            excluded_text = "\n".join(excluded_names)
            if len(EXCLUDED_SERVERS) > 5:
                excluded_text += f"\n... and {len(EXCLUDED_SERVERS) - 5} more"
            embed.add_field(name="Excluded Servers", value=excluded_text, inline=False)
    
    # Show server list
    server_list = [f"{guild.name} ({guild.member_count} members)" for guild in bot.guilds[:10]]
    if len(bot.guilds) > 10:
        server_list.append(f"... and {len(bot.guilds) - 10} more servers")
    
    embed.add_field(name="Connected Servers", value="\n".join(server_list), inline=False)
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_servers')
async def list_servers(ctx):
    """List all servers the bot is connected to"""
    
    embed = discord.Embed(
        title="🌐 Connected Servers",
        description=f"Bot is connected to {len(bot.guilds)} servers",
        color=0x00bfff
    )
    
    for i, guild in enumerate(bot.guilds[:20]):  # Show first 20 servers
        status = "❌ Excluded" if guild.id in EXCLUDED_SERVERS else "✅ Monitoring"
        embed.add_field(
            name=f"{guild.name}",
            value=f"ID: {guild.id}\nMembers: {guild.member_count}\nStatus: {status}",
            inline=True
        )
    
    if len(bot.guilds) > 20:
        embed.add_field(
            name="...",
            value=f"And {len(bot.guilds) - 20} more servers",
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe')
async def snipe(ctx):
    """Simulate sniping a promotional code"""
    
    embed = discord.Embed(
        title="🎯 Global Code Sniper Active",
        description="Searching across all servers for available codes...",
        color=0x00ff00
    )
    message = await ctx.send(embed=embed)
    
    await asyncio.sleep(2)
    
    service_type = generator.get_random_service()
    code = generator.generate_code(service_type)
    service_name = service_type.replace('_', ' ').title()
    
    embed = discord.Embed(
        title="✅ Code Sniped Successfully!",
        description=f"**Service:** {service_name}\n**Code:** `{code}`",
        color=0x00ff00
    )
    embed.add_field(name="Source", value=f"Server: {ctx.guild.name}", inline=True)
    embed.add_field(name="Status", value="Code claimed for you!", inline=True)
    embed.set_footer(text="Note: This is a simulated code for entertainment purposes")
    
    await message.edit(embed=embed)

@bot.command(name='join')
async def join_server(ctx, invite_link=None):
    """Join a server using an invite link"""
    if not invite_link:
        embed = discord.Embed(
            title="❌ Missing Invite Link",
            description="Please provide a Discord invite link",
            color=0xff0000
        )
        embed.add_field(
            name="Usage:",
            value="`!join https://discord.gg/example`\n`!join discord.gg/example`",
            inline=False
        )
        await ctx.send(embed=embed)
        return
    
    # Extract invite code from various formats
    invite_code = None
    patterns = [
        r'discord\.gg/([a-zA-Z0-9]+)',
        r'discord\.com/invite/([a-zA-Z0-9]+)',
        r'discordapp\.com/invite/([a-zA-Z0-9]+)',
        r'^([a-zA-Z0-9]+)$'  # Just the code itself
    ]
    
    for pattern in patterns:
        match = re.search(pattern, invite_link)
        if match:
            invite_code = match.group(1)
            break
    
    if not invite_code:
        embed = discord.Embed(
            title="❌ Invalid Invite Link",
            description="Could not extract invite code from the provided link",
            color=0xff0000
        )
        await ctx.send(embed=embed)
        return
    
    try:
        # Send initial message
        embed = discord.Embed(
            title="🔄 Joining Server...",
            description=f"Attempting to join server with invite: `{invite_code}`",
            color=0xffff00
        )
        message = await ctx.send(embed=embed)
        
        # Get invite info
        invite = await bot.fetch_invite(invite_code)
        guild_name = invite.guild.name if invite.guild else "Unknown Server"
        member_count = invite.approximate_member_count
        
        # Check if bot is already in the server
        if bot.get_guild(invite.guild.id):
            embed = discord.Embed(
                title="✅ Already Monitoring Server",
                description=f"Bot is already in **{guild_name}** and actively sniping!",
                color=0x00ff00
            )
            embed.add_field(name="Server Name", value=guild_name, inline=True)
            embed.add_field(name="Members", value=f"~{member_count}", inline=True)
            embed.add_field(name="Status", value="🎯 ACTIVELY SNIPING", inline=True)
            embed.add_field(name="Auto-Monitoring", value="✅ ALL CODES" if SNIPE_ENABLED else "❌ Disabled", inline=True)
            await message.edit(embed=embed)
            return
        
        # Generate comprehensive bot invite URL with maximum permissions
        bot_invite_url = f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=3072&scope=bot&guild_id={invite.guild.id}"
        
        # Provide auto-join instructions
        embed = discord.Embed(
            title="🚀 Auto-Join Server Setup",
            description=f"Setting up automatic monitoring for **{guild_name}**\n\n**AGGRESSIVE SNIPER MODE READY!**",
            color=0xff6600
        )
        embed.add_field(name="🎯 Target Server", value=guild_name, inline=True)
        embed.add_field(name="👥 Members", value=f"~{member_count}", inline=True)
        embed.add_field(name="🆔 Server ID", value=str(invite.guild.id), inline=True)
        
        embed.add_field(
            name="🔗 INSTANT JOIN LINK",
            value=f"[🚀 AUTO-ADD BOT TO SERVER]({bot_invite_url})",
            inline=False
        )
        
        embed.add_field(
            name="⚡ WHAT HAPPENS NEXT:",
            value="1. ✅ Bot joins server automatically\n2. 🎯 Starts monitoring ALL channels\n3. 🔍 Detects ALL code types instantly\n4. 📱 Auto-claims everything found\n5. 📩 Sends you notifications",
            inline=False
        )
        
        embed.add_field(
            name="🎁 DETECTION TYPES:",
            value="• 🎮 Nitro Gifts\n• 🎬 Netflix Codes\n• 🎵 Spotify Codes\n• 📦 Amazon Gifts\n• 🎮 Gaming Codes (Steam/Epic/Xbox/PS)\n• 🔐 Account Logins\n• 💰 Crypto Addresses\n• 🎟️ Promo Codes",
            inline=False
        )
        
        embed.add_field(
            name="⚠️ AGGRESSIVE MODE:",
            value="🔥 **0.5 SECOND CLAIM SPEED**\n🎯 **MONITORS ALL MESSAGES**\n⚡ **AUTO-CLAIMS EVERYTHING**",
            inline=False
        )
        
        await message.edit(embed=embed)
        
        print(f"📋 Generated invite link for server: {guild_name}")
        
    except discord.NotFound:
        embed = discord.Embed(
            title="❌ Invite Not Found",
            description="The invite link is invalid or has expired",
            color=0xff0000
        )
        await message.edit(embed=embed)
        
    except discord.Forbidden:
        embed = discord.Embed(
            title="❌ Cannot Join Server",
            description="Bot doesn't have permission to join this server or the invite is invalid",
            color=0xff0000
        )
        await message.edit(embed=embed)
        
    except Exception as e:
        embed = discord.Embed(
            title="❌ Error Joining Server",
            description=f"An error occurred: {str(e)}",
            color=0xff0000
        )
        await message.edit(embed=embed)
        print(f"❌ Error joining server: {e}")

@bot.command(name='leave')
async def leave_server(ctx, server_id=None):
    """Leave a server (current server if no ID provided)"""
    if not server_id:
        target_guild = ctx.guild
    else:
        try:
            target_guild = bot.get_guild(int(server_id))
            if not target_guild:
                embed = discord.Embed(
                    title="❌ Server Not Found",
                    description=f"Bot is not in server with ID: {server_id}",
                    color=0xff0000
                )
                await ctx.send(embed=embed)
                return
        except ValueError:
            embed = discord.Embed(
                title="❌ Invalid Server ID",
                description="Please provide a valid server ID",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
    
    guild_name = target_guild.name
    guild_id = target_guild.id
    
    try:
        embed = discord.Embed(
            title="👋 Leaving Server...",
            description=f"Leaving **{guild_name}**",
            color=0xffff00
        )
        
        if target_guild == ctx.guild:
            await ctx.send(embed=embed)
        
        await target_guild.leave()
        
        # Remove from excluded servers if it was there
        EXCLUDED_SERVERS.discard(guild_id)
        
        success_embed = discord.Embed(
            title="✅ Successfully Left Server",
            description=f"Bot has left **{guild_name}**",
            color=0x00ff00
        )
        
        # Send to user if we can
        if USER_ID and target_guild != ctx.guild:
            user = bot.get_user(USER_ID)
            if user:
                await user.send(embed=success_embed)
        
        print(f"✅ Successfully left server: {guild_name}")
        
    except Exception as e:
        error_embed = discord.Embed(
            title="❌ Error Leaving Server",
            description=f"Failed to leave **{guild_name}**: {str(e)}",
            color=0xff0000
        )
        
        if target_guild == ctx.guild:
            await ctx.send(embed=error_embed)
        elif USER_ID:
            user = bot.get_user(USER_ID)
            if user:
                await user.send(embed=error_embed)
        
        print(f"❌ Error leaving server {guild_name}: {e}")

@bot.command(name='invite_bot')
async def invite_bot(ctx, guild_id=None):
    """Generate a bot invite link for a specific server or general use"""
    
    if guild_id:
        try:
            guild_id = int(guild_id)
            invite_url = f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=68608&scope=bot&guild_id={guild_id}"
            title = f"🔗 Bot Invite for Server ID: {guild_id}"
        except ValueError:
            embed = discord.Embed(
                title="❌ Invalid Server ID",
                description="Please provide a valid server ID",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
    else:
        invite_url = f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=68608&scope=bot"
        title = "🔗 General Bot Invite Link"
    
    embed = discord.Embed(
        title=title,
        description="Use this link to add the bot to a server:",
        color=0x00bfff
    )
    
    embed.add_field(
        name="📋 Invite Link",
        value=f"[Click here to add bot]({invite_url})",
        inline=False
    )
    
    embed.add_field(
        name="🔧 Permissions Included",
        value="• Read Messages\n• Send Messages\n• View Channels\n• Read Message History",
        inline=True
    )
    
    embed.add_field(
        name="🎯 After Adding",
        value="• Bot will join the server\n• Use `!snipe_enable` to start monitoring\n• All code types will be detected",
        inline=True
    )
    
    if guild_id:
        embed.add_field(
            name="📝 Note",
            value="This link is specific to the server ID provided",
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command(name='mass_invite')
async def mass_invite(ctx, *server_ids):
    """Generate multiple bot invite links for mass deployment"""
    
    if not server_ids:
        # Generate general invite link
        general_invite = f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=68608&scope=bot"
        
        embed = discord.Embed(
            title="🌐 Mass Bot Deployment",
            description="Use these methods to add the bot to multiple servers quickly:",
            color=0x00ff00
        )
        
        embed.add_field(
            name="📋 General Invite Link",
            value=f"[Add bot to any server]({general_invite})",
            inline=False
        )
        
        embed.add_field(
            name="🔧 Usage with Server IDs",
            value="`!mass_invite 123456789 987654321 555444333`\nGenerates specific invite links for each server ID",
            inline=False
        )
        
        embed.add_field(
            name="🎯 After Adding",
            value="• Bot automatically starts sniping\n• All codes are auto-claimed\n• You get notifications for everything found",
            inline=False
        )
        
        embed.add_field(
            name="⚡ Aggressive Mode",
            value="• 1 second claim rate\n• Monitors ALL message types\n• Auto-detects 5+ code formats",
            inline=False
        )
        
        await ctx.send(embed=embed)
        return
    
    # Generate specific invite links
    embed = discord.Embed(
        title="🎯 Mass Server Invite Links",
        description=f"Generated {len(server_ids)} bot invite links:",
        color=0x00ff00
    )
    
    for i, server_id in enumerate(server_ids[:10]):  # Limit to 10 servers
        try:
            guild_id = int(server_id)
            invite_url = f"https://discord.com/api/oauth2/authorize?client_id={bot.user.id}&permissions=68608&scope=bot&guild_id={guild_id}"
            
            embed.add_field(
                name=f"Server {i+1} (ID: {guild_id})",
                value=f"[Add bot here]({invite_url})",
                inline=False
            )
        except ValueError:
            embed.add_field(
                name=f"❌ Invalid ID: {server_id}",
                value="Must be a valid server ID number",
                inline=False
            )
    
    if len(server_ids) > 10:
        embed.add_field(
            name="⚠️ Note",
            value=f"Only showing first 10 links. You provided {len(server_ids)} server IDs.",
            inline=False
        )
    
    embed.add_field(
        name="🚀 Quick Deployment Tips",
        value="1. Click each link above\n2. Select the target server\n3. Grant permissions\n4. Bot starts auto-sniping immediately",
        inline=False
    )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_stats')
async def snipe_stats(ctx):
    """Show detailed sniping statistics"""
    
    embed = discord.Embed(
        title="📊 Global Sniper Statistics",
        description="Real-time sniping performance across all servers",
        color=0x00ff00
    )
    
    # Server stats
    total_servers = len(bot.guilds)
    monitored = total_servers - len(EXCLUDED_SERVERS)
    total_members = sum(guild.member_count or 0 for guild in bot.guilds)
    
    embed.add_field(name="🌐 Total Servers", value=f"{total_servers}", inline=True)
    embed.add_field(name="👁️ Monitoring", value=f"{monitored}", inline=True)
    embed.add_field(name="👥 Total Members", value=f"{total_members:,}", inline=True)
    
    # Configuration stats
    embed.add_field(name="⚡ Status", value="🟢 AGGRESSIVE" if SNIPE_ENABLED else "🔴 DISABLED", inline=True)
    embed.add_field(name="🎯 Auto-Claim", value="✅ ALL CODES" if AUTO_CLAIM_ALL else "❌ DISABLED", inline=True)
    embed.add_field(name="⏱️ Rate Limit", value="1 second", inline=True)
    
    # Detection capabilities
    embed.add_field(
        name="🔍 Detection Types",
        value="• Nitro Gift Links\n• Promotional Codes\n• Steam Keys\n• Account Credentials\n• Crypto Addresses",
        inline=False
    )
    
    # Top servers by activity
    server_list = []
    for guild in sorted(bot.guilds, key=lambda g: g.member_count or 0, reverse=True)[:5]:
        status = "❌" if guild.id in EXCLUDED_SERVERS else "✅"
        server_list.append(f"{status} {guild.name} ({guild.member_count or 0} members)")
    
    if server_list:
        embed.add_field(
            name="🏆 Top Servers (by members)",
            value="\n".join(server_list),
            inline=False
        )
    
    await ctx.send(embed=embed)

@bot.command(name='snipe_help')
async def snipe_help(ctx):
    """Show available snipe commands"""
    
    embed = discord.Embed(
        title="🎯 Global Sniper Bot Commands",
        description="Commands for monitoring all servers:",
        color=0x00bfff
    )
    
    embed.add_field(
        name="**Control:**",
        value="`!snipe_enable` - Enable global monitoring\n"
              "`!snipe_disable` - Disable global monitoring\n"
              "`!snipe_status` - Show current status",
        inline=False
    )
    
    embed.add_field(
        name="**Server Management:**",
        value="`!snipe_exclude_server [id]` - Exclude server\n"
              "`!snipe_include_server [id]` - Include server\n"
              "`!snipe_servers` - List all servers\n"
              "`!join <invite_link>` - Get bot invite for server\n"
              "`!invite_bot [server_id]` - Generate bot invite link\n"
              "`!mass_invite [ids...]` - Mass deployment links\n"
              "`!leave [server_id]` - Leave a server",
        inline=False
    )
    
    embed.add_field(
        name="**Statistics & Tools:**",
        value="`!snipe` - Generate a random code\n"
              "`!snipe_stats` - Show detailed statistics\n"
              "`!snipe_help` - Show this help message",
        inline=False
    )
    
    embed.add_field(
        name="**Detection Types:**",
        value="🎁 Nitro Gift Links\n"
              "🎬 Netflix Codes & Gifts\n"
              "🎵 Spotify Premium Codes\n"
              "📦 Amazon Gift Cards\n"
              "🎮 Gaming Codes (Steam/Epic/Xbox/PlayStation)\n"
              "🟣 Twitch Prime Codes\n"
              "📱 Google Play & Apple/iTunes\n"
              "🎟️ General Promotional Codes\n"
              "🔐 Account Credentials\n"
              "💰 Crypto Addresses",
        inline=False
    )
    
    embed.add_field(
        name="⚠️ Warning",
        value="Global monitoring may violate Discord's Terms of Service",
        inline=False
    )
    
    await ctx.send(embed=embed)

# Error handling
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("❌ Command not found! Use `!snipe_help` to see available commands.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ Missing required argument! Use `!snipe_help` for command usage.")
    else:
        await ctx.send(f"❌ An error occurred: {str(error)}")

# Run the bot
if __name__ == "__main__":
    print("🤖 Starting Global Discord Sniper Bot...")
    print("📝 Don't forget to:")
    print("   1. Set your DISCORD_BOT_TOKEN in Secrets")
    print("   2. Invite the bot to your servers with message content permissions")
    print("   3. Use !snipe_help to see commands")
    print("   4. Enable sniping with !snipe_enable")
    print("🌐 This bot will monitor ALL servers it has access to!")
    print("⚠️  WARNING: This may violate Discord's Terms of Service!")
    
    import os
    token = os.getenv('DISCORD_BOT_TOKEN')
    
    if not token:
        print("❌ Error: DISCORD_BOT_TOKEN not found in environment variables!")
        print("   Please add your Discord bot token to Replit Secrets.")
    else:
        bot.run(token)
